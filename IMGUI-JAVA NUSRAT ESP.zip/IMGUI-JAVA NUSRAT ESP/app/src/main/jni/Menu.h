

#include "Variable.h"
#include "Draw/hooks.h"
#include "Draw/ESPManager.h"
ESPManager *espManager;
#include "DrawingESP.h"
#include "Functions.h"
#include "Chams.h"


//------------------------MENU IMGUI-------------------------------

void BeginDraw() {
        

        ImGuiIO & io = ImGui::GetIO();
		
		DrawESP(ImGui::GetBackgroundDrawList(), ScreenWidht, ScreenHeight);
		
		
        const ImGuiViewport* main_viewport = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(ImVec2(main_viewport->WorkPos.x + 250, main_viewport->WorkPos.y + 20), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(810, 630), ImGuiCond_FirstUseEver);
   
        char buf[128];
        sprintf(buf, " <<<----[ NUSRAT ESP MOD | @MOD_BY_69 ]---->>>");//SET HERE NAME
        if (ImGui::Begin(buf)) {
			g_window = ImGui::GetCurrentWindow();
			
			
			
			
			     AnimParticles();
				 
				 
					 
			if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll)) {
			if (ImGui::BeginTabItem(ICON_FA_EYE"  ESP")) {
					
		     //ADD YOURSELF HERE
                    ImGui::Checkbox("Enable Esp", &Esp);// 1
                    ImGui::Checkbox("Esp Line", &ESPLine);// 2
                    ImGui::Checkbox("Esp Box", &ESPBox);// 3
					ImGui::Checkbox("Esp Count", &ESPObject); 
					//ImGui::Checkbox("ESP Distance", &ESPDistance);
					//ImGui::Checkbox("Esp Gradiente Box", &ESPGradientBox);
				
					
				
					
					
					ImGui::ColorEdit3("Esp Box Colour", (float *) &ESPBoxColor,
                                      ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);
			        ImGui::SameLine();  
			     	ImGui::PushItemWidth(250);
					ImGui::SliderFloat("##EspBox", &ESPBoxSize, 0.f, 10.0f);
					ImGui::PopItemWidth();
				    ImGui::SameLine();
					ImGui::Text("Esp Box Size");
					
					
					
				
				 ImGui::ColorEdit3("Esp Line Colour", (float *) &ESPLineColor,
                                      ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);				  
					ImGui::SameLine();
					ImGui::PushItemWidth(250); //Tamanho do Slider
					ImGui::SliderFloat("##EspLine", &ESPLineSize, 0.f, 10.0f);
					ImGui::PopItemWidth();
					ImGui::SameLine();
					ImGui::Text("Esp Line Size");
					          
					                    
					                              
					                                        
					                                                  
					                                                            
					                                                                      
					                                                                                
					                                                                                          
					                                                                                                    
					                                                                                                              
					                                                                                                                                  
                 //   ImGui::Checkbox("Esp Gradiente", &ESPGradientBox);
				
			ImGui::EndTabItem();
			} 
		ImGui::EndTabBar();
        } 
		
		
		
		
		
		
		if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll)) {
			if (ImGui::BeginTabItem(ICON_FA_CAMERA"   CHAMS")) {
				
				
                     ImGui::Checkbox("chams", &chams);
					 ImGui::Checkbox("shading", &shading);
					 ImGui::Checkbox("wireframe", &wireframe);
					 ImGui::Checkbox("glow", &glow);
					 ImGui::Checkbox("outline Esp", &outline);
					 ImGui::Checkbox("rainbow", &rainbow);
				ImGui::EndTabItem();
			} 
		ImGui::EndTabBar();
        } 
		
		
		
		
		
		
		
		if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll)) {
			if (ImGui::BeginTabItem(ICON_FA_INFO"   INFORMATION")) {
                
				JNIEnv* env = GetJNIEnv();
				
                 if (!env) {
                 ImGui::Text("Erro ao obter o ambiente JNI.");
                 return;
                 }

				 ImGui::Separator();
                 std::string deviceModel = GetDeviceModel(env);
                 ImGui::Text("Device Name: %s", deviceModel.c_str());
		
                    
				 std::string dateTime = GetCurrentDateTime();
                 ImGui::Text("Date and Time: %s", dateTime.c_str());
				 ImGui::Separator();


				 //COLOR CHANGE YOURSELF HAVE 
				   ImGui::Spacing();
					ImGui::TextColored (ImVec4 (245.00f, 250.00f, 255.00f, 255.00f), "  Telegram Group: ");
					ImGui::SameLine();
					if (ImGui::Button(ICON_FA_TELEGRAM"  Telegram")) {
                    OpenURL("https://t.me/snmodder");//Add YOU LINK
                    }
				ImGui::EndTabItem();           
			  } 
			ImGui::EndTabBar();
           }
			
			
         }
      }

//---------------------------------------------------------------





void FunçõesHooks() {
	
	espManager = new ESPManager();
	
	
	//OTHER GAMES OFFSET DIFFERENT 
	
	//FIND YOURSELF.  
	
	auto PersonTarget = new LoadClass("", OBFUSCATE("RotateDefalult")); //RotateDefalult
    DWORD UpDate = PersonTarget->GetMethodOffsetByName(OBFUSCATE("Update"), 0); //Update
    DWORD OnDestroy = PersonTarget->GetMethodOffsetByName(OBFUSCATE("OnDestroy"), 0);
	HOOK_AU((void *)UpDate, (void *)PlayerUpdate, old_PlayerUpdate);
	HOOK_AU((void *)OnDestroy, (void *)PlayerOnDestroy, old_PlayerOnDestroy);
	
	/*
	auto Animatorr = new LoadClass("UnityEngine", OBFUSCATE("Animator"));
	isBone = Animatorr->GetMethodOffsetByName(OBFUSCATE("GetBoneTransform"), 1);
	
	GetBoneTransform = (void*(*)(void*,int))isBone;

	*/
	
	//DO NOT CHANGE HERE
	
    auto Screen = new LoadClass("UnityEngine", OBFUSCATE("Screen"));
	get_heights = Screen->GetMethodOffsetByName(OBFUSCATE("get_height"), 0);
	get_widths = Screen->GetMethodOffsetByName(OBFUSCATE("get_width"), 0);
    //DWORD ThisScreen = Screen->GetMethodOffsetByName(OBFUSCATE("SetResolution"), 3);
    //HOOK_AU((void *)ThisScreen, (void *)SetResolution, this_ScreenResolution);
	
	auto Trans = new LoadClass("UnityEngine", OBFUSCATE("Transform"));
    auto Comp = new LoadClass("UnityEngine", OBFUSCATE("Component"));
    auto Cam = new LoadClass("UnityEngine", OBFUSCATE("Camera"));
	
	
	//SetLocalScale = (void (*)(void*, Vector3)) Trans->GetMethodOffsetByName(OBFUSCATE("set_localScale_Injected"), 1);
    getAddr::Position = Trans->GetMethodOffsetByName(OBFUSCATE("get_position_Injected"), 1);
    getAddr::SetPosition = Trans->GetMethodOffsetByName(OBFUSCATE("set_position_Injected"), 1);
    getAddr::Transform = Comp->GetMethodOffsetByName(OBFUSCATE("get_transform"), 0);
    getAddr::WorldTScrn = Cam->GetMethodOffsetByName(OBFUSCATE("WorldToScreenPoint_Injected"), 3);
    getAddr::Camera = Cam->GetMethodOffsetByName(OBFUSCATE("get_main"), 0);
	
	
	get_height = (int(*)())get_heights;
	
	get_width = (int(*)())get_widths;
	

}
